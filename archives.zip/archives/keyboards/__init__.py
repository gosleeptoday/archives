"Тут мы храним все используемые нами клавиатуры"

from .user import start_k