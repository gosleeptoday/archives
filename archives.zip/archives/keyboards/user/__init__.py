"Тут мы храним все используемые нами клавиатуры"

from .ActionsKeyboard import actions_keyboard as start_k


